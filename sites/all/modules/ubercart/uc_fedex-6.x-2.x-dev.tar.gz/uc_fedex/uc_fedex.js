// $Id: uc_fedex.js,v 1.3 2010/02/28 19:44:03 tr Exp $

(function ($) {  // Put definition of $ into local scope so jQuery code
                 // doesn't conflict with other JavaScript libraries
  Drupal.behaviors.uc_fedex = function() {
  };

}) (jQuery);  // End local scope for $
