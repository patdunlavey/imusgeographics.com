// $Id: README.txt,v 1.1.4.2 2009/04/27 22:53:50 jcnventura Exp $

This directory should be used to place the downloaded external libs used by
the print module (such as TCPDF, dompdf, etc.).
